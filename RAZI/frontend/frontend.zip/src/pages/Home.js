import React from 'react';
import '../styles.css';

const Home = () => {
  return (
    <div className="container">
      <h1 className="title">Statistika</h1>
      <p>Tukaj bo prikaz statistike, ko bo implementirana.</p>
    </div>
  );
};

export default Home;