export const API_BASE_URL = 'https://prehranko-production.up.railway.app/api'; // Enoten URL
export const CAMERA_API_URL = 'https://prehrankopython-production.up.railway.app'; // URL za kamero